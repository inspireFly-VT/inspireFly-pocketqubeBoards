G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-05-03T18:20:01-04:00*
G04 #@! TF.ProjectId,FlatpitchedCable,466c6174-7069-4746-9368-65644361626c,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-05-03 18:20:01*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.100000X-0.130000X-0.100000X0.130000X-0.100000X0.130000X0.100000X-0.130000X0.100000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X45510000Y-24550000D03*
X46150000Y-24550000D03*
G04 #@! TD*
M02*
